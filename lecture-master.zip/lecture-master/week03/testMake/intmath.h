#ifndef INT_MATH
#define INT_MATH

int gcd(int i, int j);
int lcm(int i, int j);

#endif
