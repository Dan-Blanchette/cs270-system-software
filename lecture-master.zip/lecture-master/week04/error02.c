#include <stdio.h>

/* Print "hello, world" to stdout and return 0.*/
int main()
{
    printf("hello, world\n")
    return 0;
}