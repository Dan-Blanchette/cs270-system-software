#include <stdio.h>

/* Print "hello, world" to stdout and return 0.*/
int main()
{
    print("hello, world\n");
    return 0;
}