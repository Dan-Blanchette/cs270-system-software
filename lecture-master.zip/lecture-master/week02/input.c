#include <stdio.h>
int main()
{
    int num,num2;
    printf("Enter an integer: ");
    scanf("%d%d", &num, &num2);  
    printf("Number = %d\n",num);
    printf("Number2 = %d\n",num2);
    return 0;
}