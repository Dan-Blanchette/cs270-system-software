#ifndef PALINDROME_H
#define PALINDROM_H

// Function Prototype
int palindrome(char *str);

#endif